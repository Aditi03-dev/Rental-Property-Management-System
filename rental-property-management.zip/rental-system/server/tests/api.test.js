import { after, before, test } from "node:test";
import assert from "node:assert/strict";
import mongoose from "mongoose";
import { MongoMemoryServer } from "mongodb-memory-server";
import request from "supertest";
import app from "../src/app.js";
import User from "../src/models/User.js";
import Property from "../src/models/Property.js";
import { seedDemoData } from "../src/scripts/seed.js";

let mongo;

before(async () => {
  process.env.JWT_SECRET = "test-secret-with-enough-entropy";
  mongo = await MongoMemoryServer.create();
  await mongoose.connect(mongo.getUri());
});

after(async () => {
  await mongoose.disconnect();
  await mongo.stop();
});

test("register, authenticate, and reject invalid property input", async () => {
  const registration = await request(app).post("/api/auth/register").send({
    name: "Test Tenant",
    email: "tenant@example.test",
    password: "SecurePass123",
    role: "tenant",
  });
  assert.equal(registration.status, 201);
  assert.equal(registration.body.data.user.role, "tenant");
  assert.ok(registration.body.data.token);

  const me = await request(app)
    .get("/api/auth/me")
    .set("Authorization", `Bearer ${registration.body.data.token}`);
  assert.equal(me.status, 200);
  assert.equal(me.body.data.user.email, "tenant@example.test");

  const denied = await request(app)
    .post("/api/properties")
    .set("Authorization", `Bearer ${registration.body.data.token}`)
    .send({});
  assert.equal(denied.status, 403);

  const invalid = await request(app).post("/api/auth/register").send({
    name: "x",
    email: "not-an-email",
    password: "short",
  });
  assert.equal(invalid.status, 400);
});

test("property listing supports filters, sorting, and pagination", async () => {
  const owner = await request(app).post("/api/auth/register").send({
    name: "Test Owner",
    email: "owner@example.test",
    password: "SecurePass123",
    role: "owner",
  });
  const token = owner.body.data.token;

  for (const [title, price] of [["Bright City Flat", 1200], ["Modern City Home", 2200]]) {
    const response = await request(app)
      .post("/api/properties")
      .set("Authorization", `Bearer ${token}`)
      .send({
        title,
        description: "A comfortable rental home with plenty of natural light.",
        location: "Austin, TX",
        price,
        type: "Apartment",
        bedrooms: 2,
        bathrooms: 1,
        area: 900,
        amenities: ["Laundry"],
      });
    assert.equal(response.status, 201);
  }

  const result = await request(app).get("/api/properties?location=Austin&type=Apartment&sort=price-asc&page=1&limit=1");
  assert.equal(result.status, 200);
  assert.equal(result.body.data.pagination.total, 2);
  assert.equal(result.body.data.properties.length, 1);
  assert.equal(result.body.data.properties[0].price, 1200);
});

test("tenants can contact owners and manage saved homes", async () => {
  const [owner, tenant, otherOwner] = await Promise.all([
    request(app).post("/api/auth/register").send({
      name: "Inquiry Owner",
      email: "inquiry-owner@example.test",
      password: "SecurePass123",
      role: "owner",
    }),
    request(app).post("/api/auth/register").send({
      name: "Inquiry Tenant",
      email: "inquiry-tenant@example.test",
      password: "SecurePass123",
      role: "tenant",
    }),
    request(app).post("/api/auth/register").send({
      name: "Other Owner",
      email: "other-owner@example.test",
      password: "SecurePass123",
      role: "owner",
    }),
  ]);
  const ownerToken = owner.body.data.token;
  const tenantToken = tenant.body.data.token;
  const listing = await request(app)
    .post("/api/properties")
    .set("Authorization", `Bearer ${ownerToken}`)
    .send({
      title: "Quiet Garden Apartment",
      description: "A welcoming apartment with a peaceful private garden.",
      location: "Madison, WI",
      price: 1600,
      type: "Apartment",
      bedrooms: 2,
      bathrooms: 1,
      area: 940,
    });
  assert.equal(listing.status, 201);

  const favorite = await request(app)
    .post(`/api/favorites/${listing.body.data.property._id}`)
    .set("Authorization", `Bearer ${tenantToken}`);
  assert.equal(favorite.status, 201);

  const inquiry = await request(app)
    .post("/api/inquiries")
    .set("Authorization", `Bearer ${tenantToken}`)
    .send({ propertyId: listing.body.data.property._id, message: "Could I arrange a viewing this weekend?" });
  assert.equal(inquiry.status, 201);

  const inbox = await request(app).get("/api/inquiries/my").set("Authorization", `Bearer ${ownerToken}`);
  assert.equal(inbox.status, 200);
  assert.equal(inbox.body.data.inquiries.length, 1);
  assert.equal(inbox.body.data.inquiries[0].tenant.email, "inquiry-tenant@example.test");

  const saved = await request(app).get("/api/favorites/my").set("Authorization", `Bearer ${tenantToken}`);
  assert.equal(saved.body.data.properties[0]._id, listing.body.data.property._id);

  const forbidden = await request(app)
    .put(`/api/properties/${listing.body.data.property._id}`)
    .set("Authorization", `Bearer ${otherOwner.body.data.token}`)
    .send({ title: "Trying to edit someone else's home" });
  assert.equal(forbidden.status, 403);

  const removed = await request(app)
    .delete(`/api/favorites/${listing.body.data.property._id}`)
    .set("Authorization", `Bearer ${tenantToken}`);
  assert.equal(removed.status, 200);
  assert.equal(removed.body.data.favorites.length, 0);
});

test("development seed adds sample homes with photos only to an empty database", async () => {
  await Promise.all([Property.deleteMany({}), User.deleteMany({})]);

  assert.equal(await seedDemoData({ onlyWhenEmpty: true }), true);
  assert.equal(await Property.countDocuments(), 18);
  assert.equal(await User.countDocuments(), 3);
  assert.ok(await Property.exists({ images: { $elemMatch: { $regex: /^https:\/\/images\.unsplash\.com\// } } }));
  assert.equal(await seedDemoData({ onlyWhenEmpty: true }), false);
  assert.equal(await Property.countDocuments(), 18);
});
