import "dotenv/config";
import app from "./app.js";
import { connectDatabase } from "./config/database.js";
import { seedDemoData } from "./scripts/seed.js";

const port = Number(process.env.PORT) || 5000;

try {
  if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) {
    throw new Error("JWT_SECRET must be set to at least 32 characters");
  }
  await connectDatabase();
  if (process.env.NODE_ENV === "development") {
    await seedDemoData({ onlyWhenEmpty: true });
  }
  const server = app.listen(port, () => {
    console.log(`Rental system API listening on port ${port}`);
  });

  for (const signal of ["SIGINT", "SIGTERM"]) {
    process.on(signal, () => {
      server.close(() => process.exit(0));
    });
  }
} catch (error) {
  console.error("Unable to start server:", error);
  process.exitCode = 1;
}
