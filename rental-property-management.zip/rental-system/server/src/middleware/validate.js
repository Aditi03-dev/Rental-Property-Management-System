import fs from "node:fs/promises";
import { validationResult } from "express-validator";
import { HttpError } from "../utils/httpError.js";

export function validate(req, res, next) {
  const result = validationResult(req);
  if (!result.isEmpty()) {
    const errors = result.array().map(({ path, msg }) => ({ field: path, message: msg }));
    const validationError = Object.assign(new HttpError(400, "Please correct the highlighted fields"), { errors });
    const files = req.files || [];
    return Promise.all(files.map(async (file) => {
      try {
        await fs.unlink(file.path);
      } catch (error) {
        if (error.code !== "ENOENT") throw error;
      }
    })).then(() => next(validationError), next);
  }
  return next();
}
