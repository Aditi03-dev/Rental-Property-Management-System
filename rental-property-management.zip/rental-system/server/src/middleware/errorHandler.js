import mongoose from "mongoose";

export function notFound(req, res, next) {
  const error = new Error(`Route not found: ${req.method} ${req.originalUrl}`);
  error.status = 404;
  next(error);
}

export function errorHandler(error, req, res, _next) {
  let status = error.status || 500;
  let message = error.message || "Internal server error";
  let errors = error.errors;

  if (error instanceof mongoose.Error.ValidationError) {
    status = 400;
    message = "Validation failed";
    errors = Object.values(error.errors).map(({ path, message: detail }) => ({
      field: path,
      message: detail,
    }));
  } else if (error instanceof mongoose.Error.CastError) {
    status = 400;
    message = "Invalid resource identifier";
  } else if (error.code === 11000) {
    status = 409;
    message = "An account with that email already exists";
  } else if (error.name === "MulterError") {
    status = 400;
    message = error.code === "LIMIT_FILE_SIZE"
      ? "Each image must be 5 MB or smaller"
      : "Image upload limits exceeded";
  }

  if (status >= 500) console.error(error);
  res.status(status).json({
    success: false,
    message: status >= 500 && process.env.NODE_ENV === "production"
      ? "Internal server error"
      : message,
    ...(errors ? { errors } : {}),
  });
}
