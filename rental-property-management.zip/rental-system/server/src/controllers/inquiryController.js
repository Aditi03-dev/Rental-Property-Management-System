import Inquiry from "../models/Inquiry.js";
import Property from "../models/Property.js";
import { HttpError } from "../utils/httpError.js";

export async function createInquiry(req, res) {
  const property = await Property.findById(req.body.propertyId);
  if (!property || !property.isAvailable) throw new HttpError(404, "Property not found");
  if (property.owner.toString() === req.user.id) {
    throw new HttpError(400, "You cannot send an inquiry about your own property");
  }
  const inquiry = await Inquiry.create({
    property: property.id,
    tenant: req.user.id,
    owner: property.owner,
    message: req.body.message,
  });
  res.status(201).json({ success: true, data: { inquiry } });
}

export async function listOwnerInquiries(req, res) {
  const inquiries = await Inquiry.find({ owner: req.user.id })
    .populate("property", "title location price images")
    .populate("tenant", "name email phone")
    .sort({ createdAt: -1 });
  res.json({ success: true, data: { inquiries } });
}
