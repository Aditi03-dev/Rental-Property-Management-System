import mongoose from "mongoose";
import User from "../models/User.js";
import Property from "../models/Property.js";
import { HttpError } from "../utils/httpError.js";

export async function addFavorite(req, res) {
  const { propertyId } = req.params;
  if (!mongoose.isValidObjectId(propertyId)) throw new HttpError(400, "Invalid property identifier");
  const property = await Property.findOne({ _id: propertyId, isAvailable: true });
  if (!property) throw new HttpError(404, "Property not found");
  await User.updateOne({ _id: req.user.id }, { $addToSet: { favorites: property._id } });
  const user = await User.findById(req.user.id).select("favorites");
  res.status(201).json({ success: true, data: { favorites: user.favorites } });
}

export async function removeFavorite(req, res) {
  const { propertyId } = req.params;
  if (!mongoose.isValidObjectId(propertyId)) throw new HttpError(400, "Invalid property identifier");
  await User.updateOne({ _id: req.user.id }, { $pull: { favorites: propertyId } });
  const user = await User.findById(req.user.id).select("favorites");
  res.json({ success: true, data: { favorites: user.favorites } });
}

export async function listFavorites(req, res) {
  const user = await User.findById(req.user.id).select("favorites");
  const properties = await Property.find({ _id: { $in: user.favorites }, isAvailable: true })
    .populate("owner", "name phone")
    .sort({ createdAt: -1 });
  res.json({ success: true, data: { properties } });
}
