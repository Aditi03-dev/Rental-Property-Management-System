import jwt from "jsonwebtoken";
import User from "../models/User.js";
import { HttpError } from "../utils/httpError.js";

function publicUser(user) {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    phone: user.phone,
    favorites: user.favorites || [],
  };
}

function issueToken(user) {
  if (!process.env.JWT_SECRET) throw new Error("JWT_SECRET is not configured");
  return jwt.sign({ sub: user.id, role: user.role }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || "7d",
  });
}

export async function register(req, res) {
  const { name, email, password, role, phone } = req.body;
  const user = await User.create({ name, email, password, role, phone });
  res.status(201).json({ success: true, data: { user: publicUser(user), token: issueToken(user) } });
}

export async function login(req, res) {
  const user = await User.findOne({ email: req.body.email }).select("+password");
  if (!user || !(await user.comparePassword(req.body.password))) {
    throw new HttpError(401, "Email or password is incorrect");
  }
  res.json({ success: true, data: { user: publicUser(user), token: issueToken(user) } });
}

export async function me(req, res) {
  res.json({ success: true, data: { user: publicUser(req.user) } });
}
