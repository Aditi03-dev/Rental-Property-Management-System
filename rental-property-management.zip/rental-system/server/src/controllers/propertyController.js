import fs from "node:fs/promises";
import path from "node:path";
import Property from "../models/Property.js";
import { HttpError } from "../utils/httpError.js";
import { escapeRegex, parsePagination } from "../utils/propertyQuery.js";

function propertyInput(body) {
  const fields = ["title", "description", "location", "price", "type", "bedrooms", "bathrooms", "area", "amenities", "isAvailable"];
  const input = Object.fromEntries(fields.filter((field) => body[field] !== undefined).map((field) => [field, body[field]]));
  if (typeof input.amenities === "string") {
    try {
      input.amenities = JSON.parse(input.amenities);
    } catch {
      input.amenities = input.amenities.split(",").map((item) => item.trim()).filter(Boolean);
    }
  }
  if (input.amenities !== undefined && (!Array.isArray(input.amenities) || input.amenities.some((item) => typeof item !== "string"))) {
    throw new HttpError(400, "Amenities must be a list of text values");
  }
  for (const field of ["price", "bedrooms", "bathrooms", "area"]) {
    if (input[field] !== undefined) input[field] = Number(input[field]);
  }
  if (typeof input.isAvailable === "string") input.isAvailable = input.isAvailable === "true";
  return input;
}

function uploadedPaths(files = []) {
  return files.map((file) => `/uploads/${file.filename}`);
}

async function removeLocalImages(images) {
  await Promise.all(images.filter((image) => image.startsWith("/uploads/")).map(async (image) => {
    const filePath = path.resolve(process.env.UPLOAD_DIR || "uploads", path.basename(image));
    try {
      await fs.unlink(filePath);
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
    }
  }));
}

export async function listProperties(req, res) {
  const { page, limit, skip } = parsePagination(req.query);
  const filter = { isAvailable: true };
  if (req.query.location) filter.location = new RegExp(escapeRegex(req.query.location.trim()), "i");
  if (req.query.type) filter.type = req.query.type;
  if (req.query.minPrice || req.query.maxPrice) {
    filter.price = {};
    if (req.query.minPrice) filter.price.$gte = Number(req.query.minPrice);
    if (req.query.maxPrice) filter.price.$lte = Number(req.query.maxPrice);
  }

  const sortBy = req.query.sort === "price-asc"
    ? { price: 1 }
    : req.query.sort === "price-desc"
      ? { price: -1 }
      : { createdAt: -1 };

  const [properties, total] = await Promise.all([
    Property.find(filter).populate("owner", "name phone").sort(sortBy).skip(skip).limit(limit),
    Property.countDocuments(filter),
  ]);
  res.json({
    success: true,
    data: {
      properties,
      pagination: { page, limit, total, pages: Math.ceil(total / limit) },
    },
  });
}

export async function getProperty(req, res) {
  const property = await Property.findById(req.params.id).populate("owner", "name createdAt");
  if (!property) throw new HttpError(404, "Property not found");
  res.json({ success: true, data: { property } });
}

export async function listMyProperties(req, res) {
  const properties = await Property.find({ owner: req.user.id }).sort({ createdAt: -1 });
  res.json({ success: true, data: { properties } });
}

export async function createProperty(req, res) {
  const property = await Property.create({
    ...propertyInput(req.body),
    images: uploadedPaths(req.files),
    owner: req.user.id,
  });
  res.status(201).json({ success: true, data: { property } });
}

export async function updateProperty(req, res) {
  const property = await Property.findById(req.params.id);
  if (!property) throw new HttpError(404, "Property not found");
  if (property.owner.toString() !== req.user.id) throw new HttpError(403, "You can only manage your own properties");

  Object.assign(property, propertyInput(req.body));
  const newImages = uploadedPaths(req.files);
  if (newImages.length) property.images = [...property.images, ...newImages];
  await property.save();
  res.json({ success: true, data: { property } });
}

export async function deleteProperty(req, res) {
  const property = await Property.findById(req.params.id);
  if (!property) throw new HttpError(404, "Property not found");
  if (property.owner.toString() !== req.user.id) throw new HttpError(403, "You can only manage your own properties");

  await property.deleteOne();
  await removeLocalImages(property.images);
  res.status(204).send();
}
