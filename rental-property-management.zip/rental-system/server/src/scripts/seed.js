import "dotenv/config";
import mongoose from "mongoose";
import { resolve } from "node:path";
import { pathToFileURL } from "node:url";
import User from "../models/User.js";
import Property from "../models/Property.js";
import { connectDatabase } from "../config/database.js";

const users = [
  { name: "Olivia Carter", email: "olivia.owner@example.com", password: "OwnerDemo123!", role: "owner", phone: "+1 555 010 0101" },
  { name: "Noah Bennett", email: "noah.owner@example.com", password: "OwnerDemo123!", role: "owner", phone: "+1 555 010 0102" },
  { name: "Ava Morgan", email: "ava.tenant@example.com", password: "TenantDemo123!", role: "tenant", phone: "+1 555 010 0103" },
];

const listings = [
  ["Sunlit Downtown Loft", "Bright open-plan loft with tall windows and a private balcony close to transit.", "Austin, TX", 1850, "Apartment", 1, 1, 760, ["Balcony", "Laundry", "Pet friendly"]],
  ["Oak Grove Family Home", "Quiet, spacious home with a fenced garden and a renovated kitchen.", "Portland, OR", 2650, "House", 3, 2, 1820, ["Garden", "Garage", "Dishwasher"]],
  ["Hilltop Modern Villa", "Contemporary villa with panoramic views, a generous patio, and a private pool.", "San Diego, CA", 4800, "Villa", 4, 3, 2550, ["Pool", "Patio", "Parking"]],
  ["Maple House Private Room", "Furnished private room in a welcoming shared home near the university.", "Boston, MA", 950, "PG", 1, 1, 280, ["Furnished", "Wi-Fi", "Utilities included"]],
  ["Compact City Studio", "Thoughtfully designed studio with built-in storage in a walkable neighborhood.", "Seattle, WA", 1450, "Studio", 0, 1, 495, ["Gym", "Elevator", "Laundry"]],
  ["Riverside Two Bedroom", "Calm riverside apartment with a work-from-home nook and abundant daylight.", "Chicago, IL", 2200, "Apartment", 2, 2, 1140, ["River view", "Gym", "Doorman"]],
  ["Cedar Lane Bungalow", "Charming single-level bungalow with original details and a sunny yard.", "Denver, CO", 2350, "House", 2, 1, 1260, ["Garden", "Fireplace", "Storage"]],
  ["Palm Vista Retreat", "Airy coastal villa with a shaded outdoor dining area and ensuite bedrooms.", "Miami, FL", 5200, "Villa", 4, 3, 2780, ["Pool", "Furnished", "Parking"]],
  ["Garden District Shared Suite", "Comfortable private suite in a well-kept shared home near shops and buses.", "New Orleans, LA", 820, "PG", 1, 1, 350, ["Furnished", "Wi-Fi", "Shared kitchen"]],
  ["Parkside Micro Studio", "Smart studio apartment overlooking a neighborhood park and cafe.", "Brooklyn, NY", 1750, "Studio", 0, 1, 410, ["Park view", "Bike storage", "Laundry"]],
  ["The Willow Apartments", "Modern corner apartment with a large living area and secure package room.", "Nashville, TN", 1980, "Apartment", 2, 2, 1080, ["Balcony", "Package room", "Gym"]],
  ["Westside Craftsman", "Restored craftsman home featuring a covered porch and mature landscaping.", "Los Angeles, CA", 3650, "House", 3, 2, 1710, ["Porch", "Garden", "Parking"]],
  ["Bluewater View Villa", "Relaxed waterfront villa with private dock access and an open-plan kitchen.", "Tampa, FL", 4300, "Villa", 3, 3, 2310, ["Waterfront", "Deck", "Garage"]],
  ["Elm Street Student Living", "Move-in-ready private room with study space in a friendly shared residence.", "Raleigh, NC", 760, "PG", 1, 1, 310, ["Furnished", "Study area", "Wi-Fi"]],
  ["Midtown Bright Studio", "Efficient studio with oversized windows and easy access to local markets.", "Atlanta, GA", 1325, "Studio", 0, 1, 460, ["Laundry", "Storage", "Transit nearby"]],
  ["Lakeview Corner Flat", "Spacious apartment with lake glimpses, hardwood floors, and a breakfast bar.", "Minneapolis, MN", 2100, "Apartment", 2, 2, 1190, ["Lake view", "Balcony", "Gym"]],
  ["Redwood Family Residence", "Generous family home with a flexible office, covered patio, and quiet street.", "Sacramento, CA", 2850, "House", 4, 2, 2050, ["Office", "Patio", "Garage"]],
  ["Sage Canyon Villa", "Private desert home with clean lines, a landscaped courtyard, and mountain views.", "Phoenix, AZ", 3900, "Villa", 3, 2, 2180, ["Courtyard", "Mountain view", "Pool"]],
];

const photos = [
  "photo-1600210492486-724fe5c67fb0",
  "photo-1600047509807-ba8f99d2cdde",
  "photo-1613490493576-7fde63acd811",
  "photo-1522708323590-d24dbb6b0267",
  "photo-1502672260266-1c1ef2d93688",
  "photo-1600607687939-ce8a6c25118c",
  "photo-1600566753086-00f18fb6b3ea",
  "photo-1600607687920-4e2a09cf159d",
  "photo-1600566753190-17f0baa2a6c3",
  "photo-1600585154340-be6161a56a0c",
  "photo-1600607687939-ce8a6c25118c",
  "photo-1600047509807-ba8f99d2cdde",
  "photo-1613490493576-7fde63acd811",
  "photo-1600210492486-724fe5c67fb0",
  "photo-1502672260266-1c1ef2d93688",
  "photo-1600607687920-4e2a09cf159d",
  "photo-1600585154340-be6161a56a0c",
  "photo-1600566753086-00f18fb6b3ea",
];

export async function seedDemoData({ onlyWhenEmpty = false } = {}) {
  if (onlyWhenEmpty && await Property.exists({})) return false;

  const records = [];
  for (const userInput of users) {
    let user = await User.findOne({ email: userInput.email });
    if (!user) {
      user = await User.create(userInput);
    }
    records.push(user);
  }

  const owners = records.filter((user) => user.role === "owner");
  for (const [index, listing] of listings.entries()) {
    const [title, description, location, price, type, bedrooms, bathrooms, area, amenities] = listing;
    const image = `https://images.unsplash.com/${photos[index]}?auto=format&fit=crop&w=1200&q=85`;
    const existing = await Property.findOne({ title });
    if (existing) {
      if (!existing.images.length) {
        existing.images = [image];
        await existing.save();
      }
      continue;
    }
    await Property.create({
      title, description, location, price, type, bedrooms, bathrooms, area, amenities,
      images: [image], owner: owners[index % owners.length]._id,
    });
  }
  console.log(`Seeded ${records.length} demo users and ${listings.length} sample properties.`);
  return true;
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  try {
    await connectDatabase();
    await seedDemoData();
  } catch (error) {
    console.error("Seeding failed:", error);
    process.exitCode = 1;
  } finally {
    await mongoose.disconnect();
  }
}
