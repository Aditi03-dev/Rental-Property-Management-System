import { Router } from "express";
import { rateLimit } from "express-rate-limit";
import { body } from "express-validator";
import { login, me, register } from "../controllers/authController.js";
import { requireAuth } from "../middleware/auth.js";
import { validate } from "../middleware/validate.js";
import { asyncHandler } from "../utils/asyncHandler.js";

const router = Router();
const authRateLimit = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 20,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { success: false, message: "Too many authentication attempts. Please try again later." },
});

router.post(
  "/register",
  authRateLimit,
  [
    body("name").trim().isLength({ min: 2, max: 80 }).withMessage("Name must be 2–80 characters"),
    body("email").trim().isEmail().normalizeEmail().withMessage("Enter a valid email address"),
    body("password").isLength({ min: 8, max: 128 }).withMessage("Password must be at least 8 characters"),
    body("role").optional().isIn(["tenant", "owner"]).withMessage("Role must be tenant or owner"),
    body("phone").optional().trim().isLength({ max: 30 }),
  ],
  validate,
  asyncHandler(register)
);

router.post(
  "/login",
  authRateLimit,
  [
    body("email").trim().isEmail().normalizeEmail().withMessage("Enter a valid email address"),
    body("password").isString().notEmpty().withMessage("Password is required"),
  ],
  validate,
  asyncHandler(login)
);

router.get("/me", requireAuth, asyncHandler(me));

export default router;
