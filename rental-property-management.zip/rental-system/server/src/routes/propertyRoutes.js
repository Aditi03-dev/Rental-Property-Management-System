import { Router } from "express";
import { body, param, query } from "express-validator";
import {
  createProperty,
  deleteProperty,
  getProperty,
  listProperties,
  listMyProperties,
  updateProperty,
} from "../controllers/propertyController.js";
import { requireAuth, requireRole } from "../middleware/auth.js";
import { propertyImages } from "../middleware/upload.js";
import { validate } from "../middleware/validate.js";
import { asyncHandler } from "../utils/asyncHandler.js";

const router = Router();
const types = ["Apartment", "House", "Villa", "PG", "Studio"];
const createRules = [
  body("title").trim().isLength({ min: 5, max: 120 }).withMessage("Title must be 5–120 characters"),
  body("description").trim().isLength({ min: 20, max: 5000 }).withMessage("Description must be at least 20 characters"),
  body("location").trim().isLength({ min: 2, max: 200 }).withMessage("Location is required"),
  body("price").isFloat({ min: 1 }).withMessage("Price must be a positive number"),
  body("type").isIn(types).withMessage("Choose a valid property type"),
  body("bedrooms").isInt({ min: 0, max: 50 }).withMessage("Bedrooms must be between 0 and 50"),
  body("bathrooms").isInt({ min: 0, max: 50 }).withMessage("Bathrooms must be between 0 and 50"),
  body("area").isFloat({ min: 1 }).withMessage("Area must be a positive number"),
  body("amenities").optional().custom((value) => Array.isArray(value) || typeof value === "string")
    .withMessage("Amenities must be a list"),
];
const updateRules = [
  body("title").optional().trim().isLength({ min: 5, max: 120 }),
  body("description").optional().trim().isLength({ min: 20, max: 5000 }),
  body("location").optional().trim().isLength({ min: 2, max: 200 }),
  body("price").optional().isFloat({ min: 1 }),
  body("type").optional().isIn(types),
  body("bedrooms").optional().isInt({ min: 0, max: 50 }),
  body("bathrooms").optional().isInt({ min: 0, max: 50 }),
  body("area").optional().isFloat({ min: 1 }),
  body("amenities").optional().custom((value) => Array.isArray(value) || typeof value === "string")
    .withMessage("Amenities must be a list"),
  body("isAvailable").optional().isBoolean(),
];

router.get(
  "/",
  [
    query("location").optional().trim().isLength({ max: 200 }),
    query("minPrice").optional().isFloat({ min: 0 }),
    query("maxPrice").optional().isFloat({ min: 0 }),
    query("type").optional().isIn(types),
    query("sort").optional().isIn(["price-asc", "price-desc", "newest"]),
    query("page").optional().isInt({ min: 1 }),
    query("limit").optional().isInt({ min: 1, max: 24 }),
  ],
  validate,
  asyncHandler(listProperties)
);

router.get("/my", requireAuth, requireRole("owner"), asyncHandler(listMyProperties));

router.post(
  "/",
  requireAuth,
  requireRole("owner"),
  propertyImages,
  createRules,
  validate,
  asyncHandler(createProperty)
);

router.get(
  "/:id",
  param("id").isMongoId().withMessage("Invalid property identifier"),
  validate,
  asyncHandler(getProperty)
);

router.put(
  "/:id",
  requireAuth,
  requireRole("owner"),
  propertyImages,
  param("id").isMongoId().withMessage("Invalid property identifier"),
  updateRules,
  validate,
  asyncHandler(updateProperty)
);

router.delete(
  "/:id",
  requireAuth,
  requireRole("owner"),
  param("id").isMongoId().withMessage("Invalid property identifier"),
  validate,
  asyncHandler(deleteProperty)
);

export default router;
