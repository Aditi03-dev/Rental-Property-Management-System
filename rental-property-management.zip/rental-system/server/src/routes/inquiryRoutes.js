import { Router } from "express";
import { body } from "express-validator";
import { createInquiry, listOwnerInquiries } from "../controllers/inquiryController.js";
import { requireAuth, requireRole } from "../middleware/auth.js";
import { validate } from "../middleware/validate.js";
import { asyncHandler } from "../utils/asyncHandler.js";

const router = Router();

router.post(
  "/",
  requireAuth,
  requireRole("tenant"),
  [
    body("propertyId").isMongoId().withMessage("Select a valid property"),
    body("message").trim().isLength({ min: 10, max: 2000 }).withMessage("Message must be 10–2000 characters"),
  ],
  validate,
  asyncHandler(createInquiry)
);

router.get("/my", requireAuth, requireRole("owner"), asyncHandler(listOwnerInquiries));

export default router;
