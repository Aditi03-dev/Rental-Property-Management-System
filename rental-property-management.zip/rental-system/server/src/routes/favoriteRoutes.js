import { Router } from "express";
import { addFavorite, listFavorites, removeFavorite } from "../controllers/favoriteController.js";
import { requireAuth, requireRole } from "../middleware/auth.js";
import { asyncHandler } from "../utils/asyncHandler.js";

const router = Router();
router.use(requireAuth, requireRole("tenant"));
router.get("/my", asyncHandler(listFavorites));
router.post("/:propertyId", asyncHandler(addFavorite));
router.delete("/:propertyId", asyncHandler(removeFavorite));

export default router;
