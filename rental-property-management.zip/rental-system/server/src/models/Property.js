import mongoose from "mongoose";

const propertySchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true, maxlength: 120 },
    description: { type: String, required: true, trim: true, maxlength: 5000 },
    location: { type: String, required: true, trim: true, maxlength: 200 },
    price: { type: Number, required: true, min: 1 },
    type: {
      type: String,
      required: true,
      enum: ["Apartment", "House", "Villa", "PG", "Studio"],
    },
    bedrooms: { type: Number, required: true, min: 0, max: 50 },
    bathrooms: { type: Number, required: true, min: 0, max: 50 },
    area: { type: Number, required: true, min: 1 },
    amenities: [{ type: String, trim: true, maxlength: 60 }],
    images: [{ type: String, trim: true }],
    owner: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
      index: true,
    },
    isAvailable: { type: Boolean, default: true, index: true },
  },
  { timestamps: true }
);

propertySchema.index({ location: 1 });
propertySchema.index({ price: 1 });
propertySchema.index({ type: 1 });
propertySchema.index({ isAvailable: 1, createdAt: -1 });
propertySchema.index({ title: "text", description: "text", location: "text" });

export default mongoose.model("Property", propertySchema);
