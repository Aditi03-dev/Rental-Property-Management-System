/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#14251f",
        forest: "#184b3d",
        mint: "#e7f2ec",
        sand: "#f7f6f1",
        coral: "#e77e5e",
      },
      fontFamily: {
        sans: ["Inter", "ui-sans-serif", "system-ui", "sans-serif"],
        display: ["Manrope", "Inter", "ui-sans-serif", "sans-serif"],
      },
      boxShadow: {
        soft: "0 12px 40px rgba(20, 37, 31, 0.08)",
      },
    },
  },
  plugins: [],
};
