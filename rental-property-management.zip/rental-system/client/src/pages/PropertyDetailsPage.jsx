import { useEffect, useState } from "react";
import { ArrowLeft, Bath, BedDouble, ChevronLeft, ChevronRight, Heart, MapPin, Ruler, Send, ShieldCheck } from "lucide-react";
import { Link, useParams } from "react-router-dom";
import toast from "react-hot-toast";
import { useAuth } from "../context/AuthContext";
import { useFavorites } from "../context/FavoritesContext";
import Loading from "../components/Loading";
import { getErrorMessage, imageUrl, inquiryApi, propertyApi } from "../services/api";

const fallback = "https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1400&q=90";

export default function PropertyDetailsPage() {
  const { id } = useParams();
  const { user } = useAuth();
  const { favoriteIds, toggleFavorite } = useFavorites();
  const [property, setProperty] = useState(null);
  const [loading, setLoading] = useState(true);
  const [photo, setPhoto] = useState(0);
  const [sending, setSending] = useState(false);

  useEffect(() => {
    propertyApi.get(id).then(({ data }) => setProperty(data.data.property))
      .catch((error) => toast.error(getErrorMessage(error)))
      .finally(() => setLoading(false));
  }, [id]);

  async function sendInquiry(event) {
    event.preventDefault();
    setSending(true);
    const formElement = event.currentTarget;
    const message = new FormData(formElement).get("message");
    try {
      await inquiryApi.send({ propertyId: property._id, message });
      formElement.reset();
      toast.success("Your message has been sent to the owner");
    } catch (error) {
      toast.error(getErrorMessage(error));
    } finally {
      setSending(false);
    }
  }

  if (loading) return <Loading label="Getting the details..." />;
  if (!property) return <div className="mx-auto max-w-7xl px-5 py-16"><Link to="/" className="font-bold text-forest">← Back to homes</Link><p className="mt-6">This home could not be found.</p></div>;
  const images = property.images?.length ? property.images.map(imageUrl) : [fallback];
  const saved = favoriteIds.includes(String(property._id));

  return (
    <div className="mx-auto max-w-7xl px-5 py-8 lg:px-8 lg:py-12">
      <Link to="/" className="mb-6 inline-flex items-center gap-2 text-sm font-bold text-forest"><ArrowLeft size={17} /> Explore homes</Link>
      <div className="relative overflow-hidden rounded-[30px] bg-ink">
        <img src={images[photo]} alt={property.title} className="h-[300px] w-full object-cover sm:h-[440px] lg:h-[520px]" />
        {images.length > 1 && <><button onClick={() => setPhoto((photo + images.length - 1) % images.length)} aria-label="Previous photo" className="absolute left-4 top-1/2 grid h-11 w-11 -translate-y-1/2 place-items-center rounded-full bg-white/90"><ChevronLeft /></button><button onClick={() => setPhoto((photo + 1) % images.length)} aria-label="Next photo" className="absolute right-4 top-1/2 grid h-11 w-11 -translate-y-1/2 place-items-center rounded-full bg-white/90"><ChevronRight /></button><span className="absolute bottom-4 right-5 rounded-full bg-ink/70 px-3 py-1.5 text-xs font-bold text-white">{photo + 1} / {images.length}</span></>}
        {user?.role === "tenant" && <button onClick={() => toggleFavorite(property._id)} className="absolute right-4 top-4 flex items-center gap-2 rounded-full bg-white px-4 py-2.5 text-sm font-bold shadow"><Heart size={17} fill={saved ? "currentColor" : "none"} className={saved ? "text-coral" : ""} />{saved ? "Saved" : "Save home"}</button>}
      </div>
      <div className="grid gap-10 py-8 lg:grid-cols-[1fr_360px] lg:gap-14 lg:py-10">
        <div>
          <div className="flex flex-wrap items-center gap-3"><span className="rounded-full bg-mint px-3 py-1.5 text-xs font-bold text-forest">{property.type}</span><span className="flex items-center gap-1 text-sm text-ink/55"><MapPin size={15} />{property.location}</span></div>
          <h1 className="mt-4 font-display text-3xl font-extrabold tracking-tight sm:text-4xl">{property.title}</h1>
          <p className="mt-3 font-display text-2xl font-extrabold text-forest">${Number(property.price).toLocaleString()}<span className="ml-1 text-sm font-medium text-ink/50">/ month</span></p>
          <div className="my-7 grid grid-cols-3 gap-3 rounded-2xl border border-ink/5 bg-white p-4">
            {[{ icon: BedDouble, value: property.bedrooms === 0 ? "Studio" : `${property.bedrooms} beds` }, { icon: Bath, value: `${property.bathrooms} baths` }, { icon: Ruler, value: `${Number(property.area).toLocaleString()} sq ft` }].map(({ icon: Icon, value }) => <div key={value} className="flex flex-col items-center gap-1.5 text-center sm:flex-row sm:justify-center sm:gap-2"><Icon size={18} className="text-forest" /><span className="text-xs font-bold sm:text-sm">{value}</span></div>)}
          </div>
          <section><h2 className="font-display text-xl font-extrabold">About this home</h2><p className="mt-3 whitespace-pre-line leading-7 text-ink/65">{property.description}</p></section>
          {property.amenities?.length > 0 && <section className="mt-8"><h2 className="font-display text-xl font-extrabold">Home comforts</h2><div className="mt-4 flex flex-wrap gap-2">{property.amenities.map((amenity) => <span key={amenity} className="rounded-full bg-white px-4 py-2 text-sm font-semibold text-ink/70">{amenity}</span>)}</div></section>}
          <section className="mt-8 flex items-center gap-4 rounded-2xl bg-white p-5"><div className="grid h-12 w-12 place-items-center rounded-2xl bg-mint font-display text-lg font-extrabold text-forest">{property.owner?.name?.[0] || "O"}</div><div><p className="font-bold">{property.owner?.name || "Property owner"}</p><p className="text-sm text-ink/50">Listing owner</p></div><ShieldCheck className="ml-auto text-forest" size={22} /></section>
        </div>
        <aside className="h-fit rounded-[26px] border border-ink/5 bg-white p-6 shadow-soft lg:sticky lg:top-24">
          <p className="text-xs font-extrabold uppercase tracking-[.18em] text-coral">Love this place?</p><h2 className="mt-2 font-display text-2xl font-extrabold">Say hello to the owner.</h2>
          {user?.role === "tenant" ? <form onSubmit={sendInquiry} className="mt-5 space-y-4"><label className="block text-sm font-bold">Your message<textarea required minLength="10" maxLength="2000" rows="5" name="message" placeholder={`Hi ${property.owner?.name?.split(" ")[0] || "there"}, I’d love to know more about this home...`} className="mt-2 w-full resize-y rounded-xl border border-ink/10 bg-sand px-4 py-3 text-sm font-normal outline-none focus:border-forest" /></label><button disabled={sending} className="flex w-full items-center justify-center gap-2 rounded-full bg-forest px-5 py-3.5 text-sm font-extrabold text-white hover:bg-ink disabled:opacity-60">{sending ? "Sending..." : "Contact owner"}<Send size={16} /></button><p className="text-center text-xs text-ink/45">Your message will go straight to the property owner.</p></form> : user ? <p className="mt-4 text-sm leading-6 text-ink/60">Owner accounts can manage their listings from the dashboard.</p> : <div className="mt-5"><p className="text-sm leading-6 text-ink/60">Sign in as a tenant to ask the owner a question about this home.</p><Link to="/login" state={{ from: { pathname: `/properties/${id}` } }} className="mt-4 block rounded-full bg-forest px-5 py-3 text-center text-sm font-bold text-white">Sign in to contact</Link></div>}
        </aside>
      </div>
    </div>
  );
}
