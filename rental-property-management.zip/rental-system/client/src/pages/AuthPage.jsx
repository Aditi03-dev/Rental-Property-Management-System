import { useState } from "react";
import { ArrowLeft, ArrowRight, Check, House, KeyRound } from "lucide-react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import { useAuth } from "../context/AuthContext";
import { authApi, getErrorMessage } from "../services/api";

export default function AuthPage({ mode }) {
  const isRegister = mode === "register";
  const [submitting, setSubmitting] = useState(false);
  const { authenticate } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  async function submit(event) {
    event.preventDefault();
    setSubmitting(true);
    const form = new FormData(event.currentTarget);
    const payload = Object.fromEntries(form.entries());
    try {
      const { data } = isRegister ? await authApi.register(payload) : await authApi.login(payload);
      authenticate(data.data);
      toast.success(isRegister ? "Welcome to Nestwell!" : "Welcome back!");
      navigate(location.state?.from?.pathname || (data.data.user.role === "owner" ? "/dashboard" : "/"), { replace: true });
    } catch (error) {
      toast.error(getErrorMessage(error));
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="mx-auto grid min-h-[calc(100vh-160px)] max-w-7xl items-center gap-10 px-5 py-12 md:grid-cols-2 lg:px-8">
      <div className="mx-auto w-full max-w-md">
        <Link to="/" className="mb-8 inline-flex items-center gap-2 text-sm font-bold text-forest"><ArrowLeft size={17} /> Back to homes</Link>
        <p className="mb-2 text-xs font-extrabold uppercase tracking-[.2em] text-coral">{isRegister ? "A warm welcome" : "Good to see you"}</p>
        <h1 className="font-display text-4xl font-extrabold tracking-tight">{isRegister ? "Find your place here." : "Welcome back home."}</h1>
        <p className="mt-3 text-ink/55">{isRegister ? "Create your free account and make the search yours." : "Sign in to pick up where you left off."}</p>
        <form onSubmit={submit} className="mt-8 space-y-4 rounded-[26px] border border-ink/5 bg-white p-6 shadow-soft sm:p-8">
          {isRegister && <label className="block space-y-2 text-sm font-bold">Your name<input required minLength="2" maxLength="80" name="name" autoComplete="name" placeholder="Jamie Parker" className="w-full rounded-xl border border-ink/10 bg-sand px-4 py-3 font-normal outline-none focus:border-forest" /></label>}
          <label className="block space-y-2 text-sm font-bold">Email address<input required type="email" name="email" autoComplete="email" placeholder="you@example.com" className="w-full rounded-xl border border-ink/10 bg-sand px-4 py-3 font-normal outline-none focus:border-forest" /></label>
          <label className="block space-y-2 text-sm font-bold">Password<input required minLength={isRegister ? 8 : undefined} type="password" name="password" autoComplete={isRegister ? "new-password" : "current-password"} placeholder={isRegister ? "At least 8 characters" : "Your password"} className="w-full rounded-xl border border-ink/10 bg-sand px-4 py-3 font-normal outline-none focus:border-forest" /></label>
          {isRegister && <><label className="block space-y-2 text-sm font-bold">I’m here as<select name="role" className="w-full rounded-xl border border-ink/10 bg-sand px-4 py-3 font-normal outline-none focus:border-forest"><option value="tenant">Looking for a home</option><option value="owner">Listing a property</option></select></label><label className="block space-y-2 text-sm font-bold">Phone number <span className="font-normal text-ink/40">(optional)</span><input name="phone" type="tel" autoComplete="tel" placeholder="+1 555 000 0000" className="w-full rounded-xl border border-ink/10 bg-sand px-4 py-3 font-normal outline-none focus:border-forest" /></label></>}
          <button disabled={submitting} className="flex w-full items-center justify-center gap-2 rounded-full bg-forest px-5 py-3.5 text-sm font-extrabold text-white transition hover:bg-ink disabled:opacity-60">{submitting ? "Just a moment..." : isRegister ? "Create account" : "Sign in"} <ArrowRight size={17} /></button>
          <p className="text-center text-xs text-ink/45">Your details are kept private and secure.</p>
        </form>
        <p className="mt-6 text-center text-sm text-ink/55">{isRegister ? "Already have an account?" : "New to Nestwell?"} <Link className="font-extrabold text-forest hover:underline" to={isRegister ? "/login" : "/register"}>{isRegister ? "Sign in" : "Create an account"}</Link></p>
      </div>
      <div className="relative hidden min-h-[500px] overflow-hidden rounded-[34px] bg-forest p-10 text-white md:flex md:flex-col md:justify-between">
        <img className="absolute inset-0 h-full w-full object-cover opacity-35 mix-blend-luminosity" src="https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1200&q=85" alt="" />
        <div className="absolute inset-0 bg-gradient-to-br from-forest/90 via-forest/65 to-ink/90" />
        <div className="relative"><span className="grid h-12 w-12 place-items-center rounded-2xl bg-white/15"><House size={22} /></span><p className="mt-7 text-xs font-bold uppercase tracking-[.22em] text-white/65">A little more at home</p><h2 className="mt-3 max-w-md font-display text-4xl font-extrabold leading-tight">More than a move.<br />A place to belong.</h2></div>
        <div className="relative space-y-3">{["Real homes, thoughtfully listed", "Connect directly with property owners", "Save the places you love"].map((item) => <p key={item} className="flex items-center gap-2 text-sm text-white/85"><span className="grid h-6 w-6 place-items-center rounded-full bg-white/15"><Check size={14} /></span>{item}</p>)}<p className="flex items-center gap-2 pt-3 text-xs text-white/50"><KeyRound size={14} /> Simple, safe, and made for you</p></div>
      </div>
    </div>
  );
}
