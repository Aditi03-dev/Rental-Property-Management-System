import { useCallback, useEffect, useState } from "react";
import { ArrowRight, Bell, Heart, Home, Plus, Trash2 } from "lucide-react";
import { Link } from "react-router-dom";
import toast from "react-hot-toast";
import { useAuth } from "../context/AuthContext";
import PropertyCard from "../components/PropertyCard";
import Loading from "../components/Loading";
import { favoriteApi, getErrorMessage, propertyApi, inquiryApi } from "../services/api";

export default function DashboardPage({ view = "dashboard" }) {
  const { user } = useAuth();
  const [properties, setProperties] = useState([]);
  const [inquiries, setInquiries] = useState([]);
  const [loading, setLoading] = useState(true);
  const isOwner = user.role === "owner";
  const isFavorites = view === "favorites";

  const loadData = useCallback(async () => {
    try {
      if (isFavorites) {
        const { data } = await favoriteApi.mine();
        setProperties(data.data.properties);
      } else if (isOwner) {
        const [propertyResult, inquiryResult] = await Promise.all([propertyApi.mine(), inquiryApi.mine()]);
        setProperties(propertyResult.data.data.properties);
        setInquiries(inquiryResult.data.data.inquiries);
      }
    } catch (error) {
      toast.error(getErrorMessage(error));
    } finally {
      setLoading(false);
    }
  }, [isFavorites, isOwner]);

  useEffect(() => { loadData(); }, [loadData]);

  async function deleteProperty(property) {
    if (!window.confirm(`Delete “${property.title}”? This cannot be undone.`)) return;
    try {
      await propertyApi.remove(property._id);
      setProperties((current) => current.filter((item) => item._id !== property._id));
      toast.success("Listing deleted");
    } catch (error) {
      toast.error(getErrorMessage(error));
    }
  }

  if (loading) return <Loading label={isFavorites ? "Loading saved homes..." : "Opening your dashboard..."} />;

  return (
    <div className="mx-auto max-w-7xl px-5 py-10 lg:px-8 lg:py-14">
      <div className="mb-9 flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
        <div><p className="mb-2 text-xs font-extrabold uppercase tracking-[.2em] text-coral">{isFavorites ? "Your shortlist" : "Your Nestwell"}</p><h1 className="font-display text-4xl font-extrabold tracking-tight">{isFavorites ? "Saved homes" : `Hello, ${user.name.split(" ")[0]}.`}</h1><p className="mt-2 text-ink/55">{isFavorites ? "The places you’ve had your eye on." : isOwner ? "A little home for your listings and conversations." : "Keep track of the places you love."}</p></div>
        {isOwner && <Link to="/properties/new" className="inline-flex items-center justify-center gap-2 rounded-full bg-forest px-5 py-3 text-sm font-extrabold text-white hover:bg-ink"><Plus size={17} /> Add a property</Link>}
      </div>

      {isOwner ? <>
        <div className="mb-10 grid gap-4 sm:grid-cols-2"><div className="flex items-center gap-4 rounded-[24px] bg-forest p-5 text-white"><span className="grid h-12 w-12 place-items-center rounded-2xl bg-white/15"><Home size={22} /></span><div><p className="text-sm text-white/65">Your listings</p><p className="font-display text-2xl font-extrabold">{properties.length}</p></div></div><div className="flex items-center gap-4 rounded-[24px] bg-white p-5"><span className="grid h-12 w-12 place-items-center rounded-2xl bg-mint text-forest"><Bell size={22} /></span><div><p className="text-sm text-ink/50">New conversations</p><p className="font-display text-2xl font-extrabold">{inquiries.filter((item) => item.status === "new").length}</p></div></div></div>
        <section><h2 className="mb-5 font-display text-2xl font-extrabold">Your properties</h2>{properties.length ? <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{properties.map((property) => <div key={property._id} className="relative"><PropertyCard property={property} /><div className="absolute bottom-[92px] right-4 flex gap-2"><Link to={`/properties/${property._id}/edit`} className="rounded-full bg-white px-3 py-2 text-xs font-bold shadow">Edit</Link><button onClick={() => deleteProperty(property)} aria-label={`Delete ${property.title}`} className="grid h-8 w-8 place-items-center rounded-full bg-white text-red-600 shadow"><Trash2 size={15} /></button></div></div>)}</div> : <EmptyState title="Your first listing starts here" text="Add a property to introduce your home to its next renter." action="List a property" to="/properties/new" />}</section>
        <section className="mt-12"><h2 className="mb-5 font-display text-2xl font-extrabold">Received inquiries <span className="ml-2 rounded-full bg-mint px-2.5 py-1 align-middle text-xs text-forest">{inquiries.length}</span></h2>{inquiries.length ? <div className="space-y-3">{inquiries.map((inquiry) => <article key={inquiry._id} className="rounded-[22px] border border-ink/5 bg-white p-5"><div className="flex flex-wrap items-start justify-between gap-3"><div><p className="font-bold">{inquiry.tenant?.name || "Tenant"} <span className="font-normal text-ink/45">asked about</span> {inquiry.property?.title || "a property"}</p><p className="mt-1 text-xs text-ink/45">{inquiry.tenant?.email} {inquiry.tenant?.phone && `· ${inquiry.tenant.phone}`}</p></div><span className={`rounded-full px-3 py-1 text-xs font-bold ${inquiry.status === "new" ? "bg-[#fff1e9] text-[#b65b35]" : "bg-mint text-forest"}`}>{inquiry.status}</span></div><p className="mt-4 rounded-xl bg-sand p-4 text-sm leading-6 text-ink/65">{inquiry.message}</p><p className="mt-3 text-xs text-ink/40">{new Date(inquiry.createdAt).toLocaleString()}</p></article>)}</div> : <EmptyState title="No messages yet" text="When a renter reaches out about your place, their message will appear here." />}</section>
      </> : isFavorites ? (
        properties.length ? <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{properties.map((property) => <PropertyCard key={property._id} property={property} />)}</div> : <EmptyState title="Your saved homes live here" text="Tap the heart on a listing to keep your favorite places close." action="Explore homes" to="/" icon={<Heart size={22} />} />
      ) : <div className="rounded-[28px] bg-white p-8 text-center"><h2 className="font-display text-2xl font-extrabold">Your next home is out there.</h2><p className="mt-2 text-ink/55">Browse the latest rental homes and save the ones you love.</p><Link to="/" className="mt-5 inline-flex items-center gap-2 font-bold text-forest">Explore homes <ArrowRight size={16} /></Link></div>}
    </div>
  );
}

function EmptyState({ title, text, action, to, icon = <Home size={22} /> }) {
  return <div className="rounded-[26px] bg-white px-6 py-12 text-center"><span className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-mint text-forest">{icon}</span><h3 className="mt-4 font-display text-xl font-extrabold">{title}</h3><p className="mx-auto mt-2 max-w-md text-sm leading-6 text-ink/55">{text}</p>{action && <Link to={to} className="mt-5 inline-flex items-center gap-2 rounded-full bg-forest px-5 py-3 text-sm font-bold text-white">{action}<ArrowRight size={15} /></Link>}</div>;
}
