import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import toast from "react-hot-toast";
import Loading from "../components/Loading";
import PropertyForm from "../components/PropertyForm";
import { getErrorMessage, propertyApi } from "../services/api";

export default function PropertyEditorPage() {
  const { id } = useParams();
  const [property, setProperty] = useState(null);
  const [loading, setLoading] = useState(Boolean(id));

  useEffect(() => {
    if (!id) return;
    propertyApi.get(id).then(({ data }) => setProperty(data.data.property))
      .catch((error) => toast.error(getErrorMessage(error)))
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) return <Loading label="Loading your listing..." />;
  if (id && !property) return <div className="p-12 text-center">This listing could not be found.</div>;
  return <PropertyForm property={property} />;
}
