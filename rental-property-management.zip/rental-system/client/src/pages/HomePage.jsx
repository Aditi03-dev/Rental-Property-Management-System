import { useEffect, useState } from "react";
import { ArrowDownUp, ArrowRight, MapPin, Search, SlidersHorizontal, Sparkles } from "lucide-react";
import { Link, useSearchParams } from "react-router-dom";
import toast from "react-hot-toast";
import PropertyCard from "../components/PropertyCard";
import Loading from "../components/Loading";
import { getErrorMessage, propertyApi } from "../services/api";

const types = ["Apartment", "House", "Villa", "PG", "Studio"];
const initialFilters = { location: "", minPrice: "", maxPrice: "", type: "", sort: "newest" };

export default function HomePage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [filters, setFilters] = useState(() => Object.fromEntries([...Object.keys(initialFilters)].map((key) => [key, searchParams.get(key) || initialFilters[key]])));
  const [page, setPage] = useState(Number(searchParams.get("page")) || 1);
  const [result, setResult] = useState({ properties: [], pagination: { pages: 0, total: 0 } });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    setLoading(true);
    const params = { ...filters, page, limit: 9 };
    Object.keys(params).forEach((key) => { if (!params[key]) delete params[key]; });
    setSearchParams(params, { replace: true });
    propertyApi.list(params)
      .then(({ data }) => { if (active) setResult(data.data); })
      .catch((error) => { if (active) toast.error(getErrorMessage(error)); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [filters, page, setSearchParams]);

  function updateFilter(event) {
    setFilters((current) => ({ ...current, [event.target.name]: event.target.value }));
    setPage(1);
  }

  function clearFilters() {
    setFilters(initialFilters);
    setPage(1);
  }

  return (
    <>
      <section className="relative isolate overflow-hidden bg-forest">
        <img
          src="https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde?auto=format&fit=crop&w=2200&q=90"
          alt=""
          aria-hidden="true"
          className="absolute inset-0 z-0 h-full w-full object-cover object-center"
        />
        <div className="absolute inset-0 z-10 bg-gradient-to-r from-ink/90 via-forest/80 to-forest/40" />
        <div className="absolute right-[-9rem] top-[-10rem] z-10 h-[480px] w-[480px] rounded-full border border-white/15" />
        <div className="absolute right-[-5rem] top-[-6rem] z-10 h-[360px] w-[360px] rounded-full border border-white/15" />
        <div className="relative z-20 mx-auto grid max-w-7xl items-center gap-10 px-5 pb-12 pt-14 md:grid-cols-[1.05fr_.95fr] md:py-20 lg:px-8">
          <div className="max-w-2xl">
            <p className="mb-5 inline-flex items-center gap-2 rounded-full bg-white/15 px-3.5 py-2 text-xs font-bold text-white backdrop-blur"><Sparkles size={14} /> A better way to find your next place</p>
            <h1 className="font-display text-[clamp(2.8rem,6.6vw,5.4rem)] font-extrabold leading-[1.02] tracking-[-.055em] text-white">Find a place<br />to <span className="text-[#b8dfc7]">feel at home.</span></h1>
            <p className="mt-6 max-w-lg text-base leading-7 text-white/75 sm:text-lg">Thoughtful homes, good people, and a smoother way to find your next chapter.</p>
            <a href="#homes" className="mt-8 inline-flex items-center gap-2 rounded-full bg-white px-6 py-3.5 text-sm font-extrabold text-forest shadow-lg transition hover:-translate-y-0.5 hover:bg-[#e8efe7]">Explore homes <ArrowRight size={17} /></a>
            <div className="mt-10 flex items-center gap-3 text-sm text-white/70"><div className="flex -space-x-2">{["photo-1534528741775-53994a69daeb", "photo-1500648767791-00dcc994a43e", "photo-1531123897727-8f129e1688ce"].map((id) => <img key={id} className="h-8 w-8 rounded-full border-2 border-forest object-cover" src={`https://images.unsplash.com/${id}?auto=format&fit=crop&w=80&q=75`} alt="" />)}</div><span><strong className="text-white">A little more at home</strong> in every search</span></div>
          </div>
          <div className="relative hidden min-h-[430px] md:block">
            <img className="absolute right-0 top-2 h-[390px] w-[84%] rounded-[36px] border border-white/20 object-cover shadow-soft" src="https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1200&q=90" alt="Warm, light-filled living room" />
            <div className="absolute -bottom-1 left-0 max-w-[220px] rounded-[24px] bg-white p-4 shadow-soft">
              <p className="text-xs font-bold uppercase tracking-wider text-forest">Your next chapter</p>
              <p className="mt-1 font-display text-lg font-extrabold">Could start right here.</p>
              <span className="mt-3 inline-flex items-center gap-1 text-xs text-ink/55"><MapPin size={13} /> Lovely places, everywhere</span>
            </div>
            <div className="absolute right-[-8px] top-[-8px] grid h-16 w-16 rotate-12 place-items-center rounded-2xl bg-coral text-white shadow-lg"><span className="text-center text-[10px] font-extrabold leading-tight">HOME<br />HAPPENS</span></div>
          </div>
        </div>
      </section>

      <section id="homes" className="mx-auto max-w-7xl scroll-mt-24 px-5 py-14 lg:px-8 lg:py-20">
        <div className="mb-8 flex flex-col justify-between gap-4 md:flex-row md:items-end">
          <div><p className="mb-2 text-xs font-extrabold uppercase tracking-[.2em] text-coral">The good places</p><h2 className="font-display text-3xl font-extrabold tracking-tight sm:text-4xl">Homes worth coming home to</h2><p className="mt-2 text-ink/55">Browse spaces that fit the way you want to live.</p></div>
          <div className="flex items-center gap-2 text-sm font-semibold text-ink/50"><SlidersHorizontal size={17} />{loading ? "Finding homes..." : `${result.pagination.total} homes to explore`}</div>
        </div>
        <form onSubmit={(event) => event.preventDefault()} className="mb-8 grid gap-3 rounded-[22px] border border-ink/5 bg-white p-3 shadow-sm sm:grid-cols-2 lg:grid-cols-[1.5fr_1fr_1fr_1.2fr_auto]">
          <label className="flex items-center gap-3 rounded-xl bg-sand px-4 py-3"><MapPin size={18} className="shrink-0 text-forest" /><input name="location" value={filters.location} onChange={updateFilter} placeholder="Where do you want to live?" className="w-full bg-transparent text-sm outline-none placeholder:text-ink/40" /></label>
          <input aria-label="Minimum price" type="number" min="0" name="minPrice" value={filters.minPrice} onChange={updateFilter} placeholder="Min. rent" className="rounded-xl bg-sand px-4 py-3 text-sm outline-none placeholder:text-ink/40" />
          <input aria-label="Maximum price" type="number" min="0" name="maxPrice" value={filters.maxPrice} onChange={updateFilter} placeholder="Max. rent" className="rounded-xl bg-sand px-4 py-3 text-sm outline-none placeholder:text-ink/40" />
          <div className="flex gap-2">
            <select aria-label="Property type" name="type" value={filters.type} onChange={updateFilter} className="min-w-0 flex-1 rounded-xl bg-sand px-3 py-3 text-sm outline-none"><option value="">All home types</option>{types.map((type) => <option key={type}>{type}</option>)}</select>
            <select aria-label="Sort properties" name="sort" value={filters.sort} onChange={updateFilter} className="min-w-0 flex-1 rounded-xl bg-sand px-3 py-3 text-sm outline-none"><option value="newest">Newest</option><option value="price-asc">Price: low to high</option><option value="price-desc">Price: high to low</option></select>
          </div>
          <button type="button" onClick={clearFilters} aria-label="Clear filters" className="flex items-center justify-center gap-2 rounded-xl bg-forest px-4 py-3 text-sm font-bold text-white transition hover:bg-ink"><Search size={16} /><span className="lg:hidden">Clear filters</span></button>
        </form>
        {loading ? <Loading /> : result.properties.length ? (
          <>
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{result.properties.map((property) => <PropertyCard key={property._id} property={property} />)}</div>
            <div className="mt-10 flex items-center justify-center gap-4">
              <button onClick={() => setPage((current) => Math.max(1, current - 1))} disabled={page <= 1} className="rounded-full border border-ink/10 px-5 py-2.5 text-sm font-bold disabled:opacity-40">Previous</button>
              <span className="text-sm font-semibold text-ink/55">Page {page} of {Math.max(result.pagination.pages, 1)}</span>
              <button onClick={() => setPage((current) => Math.min(result.pagination.pages, current + 1))} disabled={page >= result.pagination.pages} className="rounded-full border border-ink/10 px-5 py-2.5 text-sm font-bold disabled:opacity-40">Next</button>
            </div>
          </>
        ) : <div className="rounded-[28px] bg-white px-6 py-16 text-center"><div className="mx-auto mb-4 grid h-14 w-14 place-items-center rounded-2xl bg-mint text-forest"><ArrowDownUp size={22} /></div><h3 className="font-display text-xl font-extrabold">No homes found just yet</h3><p className="mt-2 text-sm text-ink/55">Try a different location or loosen your filters.</p><button onClick={clearFilters} className="mt-5 font-bold text-forest">Clear all filters</button></div>}
      </section>
    </>
  );
}
