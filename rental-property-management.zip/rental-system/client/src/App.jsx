import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import { Toaster } from "react-hot-toast";
import { AuthProvider, useAuth } from "./context/AuthContext";
import { FavoritesProvider } from "./context/FavoritesContext";
import ProtectedRoute from "./components/ProtectedRoute";
import SiteLayout from "./components/SiteLayout";
import Loading from "./components/Loading";
import HomePage from "./pages/HomePage";
import AuthPage from "./pages/AuthPage";
import PropertyDetailsPage from "./pages/PropertyDetailsPage";
import DashboardPage from "./pages/DashboardPage";
import PropertyEditorPage from "./pages/PropertyEditorPage";

function DashboardEntry() {
  const { user } = useAuth();
  return user?.role === "owner" ? <DashboardPage /> : <Navigate to="/" replace />;
}

function AppRoutes() {
  return (
    <>
      <Toaster position="top-right" toastOptions={{ duration: 3500, style: { borderRadius: "14px", fontWeight: 600 } }} />
      <Routes>
        <Route element={<SiteLayout />}>
          <Route index element={<HomePage />} />
          <Route path="properties/:id" element={<PropertyDetailsPage />} />
          <Route path="login" element={<AuthPage mode="login" />} />
          <Route path="register" element={<AuthPage mode="register" />} />
          <Route element={<ProtectedRoute />}>
            <Route path="dashboard" element={<DashboardEntry />} />
          </Route>
          <Route element={<ProtectedRoute roles={["owner"]} />}>
            <Route path="properties/new" element={<PropertyEditorPage />} />
            <Route path="properties/:id/edit" element={<PropertyEditorPage />} />
          </Route>
          <Route element={<ProtectedRoute roles={["tenant"]} />}>
            <Route path="favorites" element={<DashboardPage view="favorites" />} />
          </Route>
          <Route path="*" element={<div className="mx-auto max-w-7xl px-5 py-24 text-center"><p className="text-xs font-bold uppercase tracking-[.2em] text-coral">404 · Not found</p><h1 className="mt-3 font-display text-4xl font-extrabold">This page wandered off.</h1><a href="/" className="mt-5 inline-block font-bold text-forest">Back to home</a></div>} />
        </Route>
      </Routes>
    </>
  );
}

export default function App() {
  return <BrowserRouter><AuthProvider><FavoritesProvider><AppRoutes /></FavoritesProvider></AuthProvider></BrowserRouter>;
}
