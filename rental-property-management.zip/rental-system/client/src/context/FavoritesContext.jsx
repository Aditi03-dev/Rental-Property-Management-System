import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import toast from "react-hot-toast";
import { favoriteApi, getErrorMessage } from "../services/api";
import { useAuth } from "./AuthContext";

const FavoritesContext = createContext(null);

export function FavoritesProvider({ children }) {
  const { user, setUser } = useAuth();
  const [favoriteIds, setFavoriteIds] = useState([]);

  useEffect(() => {
    setFavoriteIds((user?.favorites || []).map((favorite) => String(favorite._id || favorite)));
  }, [user]);

  const toggleFavorite = useCallback(async (propertyId) => {
    if (!user || user.role !== "tenant") {
      toast.error("Sign in as a tenant to save homes");
      return;
    }
    const id = String(propertyId);
    const isSaved = favoriteIds.includes(id);
    try {
      if (isSaved) await favoriteApi.remove(id);
      else await favoriteApi.add(id);
      const next = isSaved ? favoriteIds.filter((favorite) => favorite !== id) : [...favoriteIds, id];
      setFavoriteIds(next);
      setUser((current) => ({ ...current, favorites: next }));
      toast.success(isSaved ? "Removed from saved homes" : "Home saved");
    } catch (error) {
      toast.error(getErrorMessage(error));
    }
  }, [favoriteIds, setUser, user]);

  const value = useMemo(() => ({ favoriteIds, toggleFavorite }), [favoriteIds, toggleFavorite]);
  return <FavoritesContext.Provider value={value}>{children}</FavoritesContext.Provider>;
}

export function useFavorites() {
  const context = useContext(FavoritesContext);
  if (!context) throw new Error("useFavorites must be used inside FavoritesProvider");
  return context;
}
