import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { authApi } from "../services/api";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const logout = useCallback(() => {
    localStorage.removeItem("rental-token");
    setUser(null);
  }, []);

  useEffect(() => {
    const token = localStorage.getItem("rental-token");
    if (!token) {
      setLoading(false);
      return;
    }
    authApi.me()
      .then(({ data }) => setUser(data.data.user))
      .catch(() => logout())
      .finally(() => setLoading(false));
  }, [logout]);

  const authenticate = useCallback((payload) => {
    localStorage.setItem("rental-token", payload.token);
    setUser(payload.user);
  }, []);

  const value = useMemo(() => ({ user, loading, logout, authenticate, setUser }), [user, loading, logout, authenticate]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used inside AuthProvider");
  return context;
}
