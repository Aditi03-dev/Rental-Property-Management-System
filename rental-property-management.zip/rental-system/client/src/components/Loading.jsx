export default function Loading({ label = "Finding your next place..." }) {
  return (
    <div className="flex min-h-56 flex-col items-center justify-center gap-3 text-forest" role="status">
      <span className="h-9 w-9 animate-spin rounded-full border-4 border-forest/15 border-t-forest" />
      <span className="text-sm font-semibold">{label}</span>
    </div>
  );
}
