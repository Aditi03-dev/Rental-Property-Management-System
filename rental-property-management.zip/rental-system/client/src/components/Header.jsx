import { useState } from "react";
import { Link, NavLink, useNavigate } from "react-router-dom";
import { Heart, House, Menu, Plus, X } from "lucide-react";
import { useAuth } from "../context/AuthContext";

export default function Header() {
  const { user, logout } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);
  const navigate = useNavigate();

  function signOut() {
    logout();
    setMenuOpen(false);
    navigate("/");
  }

  const linkStyle = ({ isActive }) => `text-sm font-semibold transition-colors ${isActive ? "text-forest" : "text-ink/60 hover:text-forest"}`;
  return (
    <header className="sticky top-0 z-30 border-b border-ink/5 bg-sand/90 backdrop-blur-xl">
      <div className="mx-auto flex h-[76px] max-w-7xl items-center justify-between px-5 lg:px-8">
        <Link to="/" className="flex items-center gap-2.5" aria-label="Nestwell home">
          <span className="grid h-10 w-10 place-items-center rounded-2xl bg-forest text-white"><House size={20} strokeWidth={2.2} /></span>
          <span className="font-display text-xl font-extrabold tracking-tight text-ink">nestwell<span className="text-coral">.</span></span>
        </Link>
        <nav className="hidden items-center gap-8 md:flex">
          <NavLink to="/" className={linkStyle}>Explore homes</NavLink>
          {user?.role === "tenant" && <NavLink to="/favorites" className={linkStyle}>Saved homes</NavLink>}
          {user && <NavLink to="/dashboard" className={linkStyle}>Dashboard</NavLink>}
        </nav>
        <div className="hidden items-center gap-3 md:flex">
          {user ? (
            <>
              {user.role === "owner" && <Link to="/properties/new" className="flex items-center gap-1.5 rounded-full bg-forest px-4 py-2.5 text-sm font-bold text-white transition hover:bg-ink"><Plus size={16} /> List a home</Link>}
              <span className="ml-1 max-w-28 truncate text-sm font-semibold">{user.name.split(" ")[0]}</span>
              <button onClick={signOut} className="rounded-full border border-ink/10 px-4 py-2.5 text-sm font-semibold text-ink/70 hover:bg-white">Sign out</button>
            </>
          ) : (
            <>
              <Link to="/login" className="px-3 py-2 text-sm font-semibold text-ink/70 hover:text-forest">Log in</Link>
              <Link to="/register" className="rounded-full bg-forest px-5 py-2.5 text-sm font-bold text-white transition hover:bg-ink">Get started</Link>
            </>
          )}
        </div>
        <button className="grid h-10 w-10 place-items-center rounded-xl border border-ink/10 md:hidden" onClick={() => setMenuOpen(!menuOpen)} aria-label={menuOpen ? "Close menu" : "Open menu"}>
          {menuOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>
      {menuOpen && <div className="border-t border-ink/5 bg-sand px-5 py-4 md:hidden">
        <nav className="mx-auto flex max-w-7xl flex-col gap-4">
          <Link onClick={() => setMenuOpen(false)} to="/" className="text-sm font-semibold">Explore homes</Link>
          {user?.role === "tenant" && <Link onClick={() => setMenuOpen(false)} to="/favorites" className="flex items-center gap-2 text-sm font-semibold"><Heart size={16} /> Saved homes</Link>}
          {user && <Link onClick={() => setMenuOpen(false)} to="/dashboard" className="text-sm font-semibold">Dashboard</Link>}
          {user?.role === "owner" && <Link onClick={() => setMenuOpen(false)} to="/properties/new" className="text-sm font-semibold">List a home</Link>}
          {user ? <button className="self-start text-sm font-semibold text-ink/60" onClick={signOut}>Sign out</button> : <div className="flex gap-4"><Link onClick={() => setMenuOpen(false)} to="/login" className="text-sm font-semibold">Log in</Link><Link onClick={() => setMenuOpen(false)} to="/register" className="text-sm font-semibold text-forest">Get started</Link></div>}
        </nav>
      </div>}
    </header>
  );
}
