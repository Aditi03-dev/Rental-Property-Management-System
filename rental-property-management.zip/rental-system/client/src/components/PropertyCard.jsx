import { useState } from "react";
import { Heart, MapPin, MoveUpRight } from "lucide-react";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useFavorites } from "../context/FavoritesContext";
import { imageUrl } from "../services/api";

const fallbackImages = {
  Apartment: "https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1000&q=85",
  House: "https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde?auto=format&fit=crop&w=1000&q=85",
  Villa: "https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&w=1000&q=85",
  PG: "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=1000&q=85",
  Studio: "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?auto=format&fit=crop&w=1000&q=85",
};

export default function PropertyCard({ property }) {
  const { user } = useAuth();
  const { favoriteIds, toggleFavorite } = useFavorites();
  const saved = favoriteIds.includes(String(property._id));
  const fallbackImage = fallbackImages[property.type] || fallbackImages.Apartment;
  const [image, setImage] = useState(property.images?.[0] ? imageUrl(property.images[0]) : fallbackImage);
  return (
    <article className="group overflow-hidden rounded-[26px] border border-ink/5 bg-white shadow-sm transition duration-300 hover:-translate-y-1 hover:shadow-soft">
      <div className="relative h-60 overflow-hidden bg-mint sm:h-64">
        <Link to={`/properties/${property._id}`} aria-label={`View ${property.title}`}>
          <img className="h-full w-full object-cover transition duration-700 group-hover:scale-105" src={image} alt={property.title} loading="lazy" onError={() => setImage(fallbackImage)} />
        </Link>
        <span className="absolute left-4 top-4 rounded-full bg-white/90 px-3 py-1.5 text-xs font-bold text-forest backdrop-blur">{property.type}</span>
        {user?.role === "tenant" && <button onClick={() => toggleFavorite(property._id)} aria-label={saved ? "Remove from saved homes" : "Save home"} className={`absolute right-4 top-4 grid h-10 w-10 place-items-center rounded-full backdrop-blur transition ${saved ? "bg-coral text-white" : "bg-white/90 text-ink hover:text-coral"}`}><Heart size={18} fill={saved ? "currentColor" : "none"} /></button>}
        <div className="absolute bottom-4 left-4 rounded-2xl bg-ink/80 px-3.5 py-2 text-white backdrop-blur">
          <span className="font-display text-lg font-extrabold">${Number(property.price).toLocaleString()}</span><span className="ml-1 text-xs text-white/70">/ month</span>
        </div>
      </div>
      <div className="p-5">
        <div className="mb-2 flex items-start justify-between gap-3">
          <h3 className="font-display text-lg font-bold leading-snug text-ink">{property.title}</h3>
          <Link to={`/properties/${property._id}`} aria-label="View property" className="mt-1 grid h-8 w-8 shrink-0 place-items-center rounded-full bg-mint text-forest transition group-hover:bg-forest group-hover:text-white"><MoveUpRight size={16} /></Link>
        </div>
        <p className="flex items-center gap-1.5 text-sm text-ink/55"><MapPin size={15} />{property.location}</p>
        <div className="mt-5 flex items-center justify-between border-t border-ink/5 pt-4 text-sm text-ink/60">
          <span>{property.bedrooms === 0 ? "Studio" : `${property.bedrooms} bed${property.bedrooms === 1 ? "" : "s"}`}</span>
          <span>{property.bathrooms} bath</span>
          <span>{Number(property.area).toLocaleString()} sq ft</span>
        </div>
      </div>
    </article>
  );
}
