import { Outlet } from "react-router-dom";
import Header from "./Header";

export default function SiteLayout() {
  return (
    <>
      <Header />
      <main className="page-shell"><Outlet /></main>
      <footer className="border-t border-ink/5 bg-white/70">
        <div className="mx-auto flex max-w-7xl flex-col gap-2 px-5 py-7 text-sm text-ink/50 sm:flex-row sm:items-center sm:justify-between lg:px-8">
          <p>© {new Date().getFullYear()} Nestwell. Find a place to feel at home.</p>
          <p>Made for better renting.</p>
        </div>
      </footer>
    </>
  );
}
