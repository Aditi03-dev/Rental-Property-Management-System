import { useState } from "react";
import { ArrowLeft, ImagePlus } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import { getErrorMessage, imageUrl, propertyApi } from "../services/api";

const fields = [
  { name: "title", label: "Listing title", placeholder: "e.g. Sunlit downtown apartment", required: true },
  { name: "location", label: "Location", placeholder: "City, State", required: true },
];

export default function PropertyForm({ property }) {
  const [saving, setSaving] = useState(false);
  const [images, setImages] = useState([]);
  const navigate = useNavigate();

  async function submit(event) {
    event.preventDefault();
    setSaving(true);
    const form = new FormData(event.currentTarget);
    form.set("amenities", JSON.stringify(form.get("amenities").split(",").map((value) => value.trim()).filter(Boolean)));
    images.forEach((image) => form.append("images", image));
    try {
      if (property) await propertyApi.update(property._id, form);
      else await propertyApi.create(form);
      toast.success(property ? "Your listing has been updated" : "Your home is now listed");
      navigate("/dashboard");
    } catch (error) {
      toast.error(getErrorMessage(error));
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="mx-auto max-w-3xl px-5 py-10 lg:py-14">
      <Link to="/dashboard" className="mb-7 inline-flex items-center gap-2 text-sm font-bold text-forest"><ArrowLeft size={17} /> Back to dashboard</Link>
      <div className="mb-8">
        <p className="mb-2 text-xs font-extrabold uppercase tracking-[.2em] text-coral">{property ? "Update listing" : "Owner workspace"}</p>
        <h1 className="font-display text-4xl font-extrabold tracking-tight">{property ? "Make it feel like home." : "Share a place to call home."}</h1>
        <p className="mt-3 text-ink/55">A few thoughtful details help the right renter find your property.</p>
      </div>
      <form onSubmit={submit} className="space-y-6 rounded-[28px] border border-ink/5 bg-white p-6 shadow-soft sm:p-9">
        <div className="grid gap-5 sm:grid-cols-2">
          {fields.map((field) => <label key={field.name} className="space-y-2 text-sm font-bold">{field.label}<input required={field.required} name={field.name} defaultValue={property?.[field.name] || ""} placeholder={field.placeholder} className="w-full rounded-xl border border-ink/10 bg-sand px-4 py-3 font-normal outline-none transition focus:border-forest" /></label>)}
          <label className="space-y-2 text-sm font-bold">Monthly rent ($)<input required type="number" min="1" name="price" defaultValue={property?.price || ""} className="w-full rounded-xl border border-ink/10 bg-sand px-4 py-3 font-normal outline-none focus:border-forest" /></label>
          <label className="space-y-2 text-sm font-bold">Property type<select required name="type" defaultValue={property?.type || "Apartment"} className="w-full rounded-xl border border-ink/10 bg-sand px-4 py-3 font-normal outline-none focus:border-forest">{["Apartment", "House", "Villa", "PG", "Studio"].map((type) => <option key={type}>{type}</option>)}</select></label>
          <label className="space-y-2 text-sm font-bold">Bedrooms<input required type="number" min="0" max="50" name="bedrooms" defaultValue={property?.bedrooms ?? 1} className="w-full rounded-xl border border-ink/10 bg-sand px-4 py-3 font-normal outline-none focus:border-forest" /></label>
          <label className="space-y-2 text-sm font-bold">Bathrooms<input required type="number" min="0" max="50" name="bathrooms" defaultValue={property?.bathrooms ?? 1} className="w-full rounded-xl border border-ink/10 bg-sand px-4 py-3 font-normal outline-none focus:border-forest" /></label>
          <label className="space-y-2 text-sm font-bold sm:col-span-2">Area (sq ft)<input required type="number" min="1" name="area" defaultValue={property?.area || ""} className="w-full rounded-xl border border-ink/10 bg-sand px-4 py-3 font-normal outline-none focus:border-forest" /></label>
          <label className="space-y-2 text-sm font-bold sm:col-span-2">Description<textarea required minLength="20" maxLength="5000" rows="5" name="description" defaultValue={property?.description || ""} placeholder="What makes this home special?" className="w-full resize-y rounded-xl border border-ink/10 bg-sand px-4 py-3 font-normal outline-none focus:border-forest" /></label>
          <label className="space-y-2 text-sm font-bold sm:col-span-2">Amenities <span className="font-normal text-ink/45">(comma-separated)</span><input name="amenities" defaultValue={property?.amenities?.join(", ") || ""} placeholder="Balcony, Laundry, Parking" className="w-full rounded-xl border border-ink/10 bg-sand px-4 py-3 font-normal outline-none focus:border-forest" /></label>
        </div>
        {property?.images?.length > 0 && <div><p className="mb-2 text-sm font-bold">Current photos</p><div className="flex gap-3 overflow-x-auto">{property.images.map((image) => <img key={image} src={imageUrl(image)} alt="Current property" className="h-20 w-28 rounded-xl object-cover" />)}</div></div>}
        <label className="flex cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed border-ink/15 bg-sand p-7 text-center transition hover:border-forest/40">
          <ImagePlus className="mb-2 text-forest" size={24} /><span className="text-sm font-bold">Add property photos</span><span className="mt-1 text-xs text-ink/50">JPEG, PNG or WebP · up to 8 images · 5 MB each</span>
          <input type="file" accept="image/jpeg,image/png,image/webp" multiple onChange={(event) => setImages(Array.from(event.target.files || []))} className="sr-only" />
          {images.length > 0 && <span className="mt-2 text-xs font-bold text-forest">{images.length} photo{images.length === 1 ? "" : "s"} selected</span>}
        </label>
        <button disabled={saving} className="w-full rounded-full bg-forest px-6 py-3.5 text-sm font-extrabold text-white transition hover:bg-ink disabled:cursor-not-allowed disabled:opacity-60">{saving ? "Saving your listing..." : property ? "Save changes" : "Publish listing"}</button>
      </form>
    </div>
  );
}
